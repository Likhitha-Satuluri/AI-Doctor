import "./App.css" ;
import axios from "axios";
import { useState } from "react";

function App(){
  const [prompt, setprompt] = useState("");
  const [response,setResponse] = useState("");

  const handleSubmit = (e) =>{
    e.preventDefault();

    axios
     .post("http://localhost:5555/chat",{ prompt })
     .then((res)=>{
          setResponse(res.data);
     })
     .catch((err)=>{
      console.log(err);
     })
  };

  return (
    <div>
  <div><p>{response}</p></div>
  <input type="text"  placeholder="Keyword" value={prompt} onChange={(e)=>{setprompt(e.target.value)}} />
  <button type="Submit"  onClick={handleSubmit()}>Search</button>
  </div>
);

};

export default App ;
